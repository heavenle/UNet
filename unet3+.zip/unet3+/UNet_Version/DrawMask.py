import cv2
import numpy as np
import opt
import skimage.io as io

def draw_mask(mask, config, flag='undefined'):
    """
    将mask结果用预设的颜色画出来。注意mask必须是onehot编码形式的矩阵。

    :param mask: 需要画的mask
    :param config: 初始化参数，包含每个类别对应的颜色值
    :param flag: 最后保存的图像名字。注意：str格式。不包含后缀
    :return:无
    """
    channel, height, width = mask.shape
    img = np.zeros((height, width, 3))
    one_channel_mask = np.argmax(mask.detach().cpu().numpy().transpose(1, 2, 0), axis=-1)

    for n_class_value in config['class_value']:
        # linshi shezhi
        img[:, :, 0] += ((one_channel_mask[:, :] == n_class_value) * config['colors'][n_class_value][0]).astype('uint8')
        img[:, :, 1] += ((one_channel_mask[:, :] == n_class_value) * config['colors'][n_class_value][1]).astype('uint8')
        img[:, :, 2] += ((one_channel_mask[:, :] == n_class_value) * config['colors'][n_class_value][2]).astype('uint8')

    io.imsave('./output/'+ flag +'.jpg', img)

if __name__ == '__main__':
    output = np.load('./d1.npy')
    target = np.load('./target.npy')
    config = opt.opts()
    draw_mask(target, config, 'gt')
    draw_mask(output, config, 'pred')