import glob
import math
import torch
from torch.autograd import Variable as V
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import yaml
import numpy as np
from typing import List, Iterable, Dict, Union
import cv2
from skimage import io as skio
import json
# zhu from aiUtils import aiUtils
from PIL import Image
import io
import time
from osgeo import ogr
from osgeo import osr
from osgeo import gdal
from torch.autograd import Variable
from albumentations.core.composition import Compose
from albumentations.augmentations import transforms
import archs
import warnings
from osgeo import gdalconst
import zipfile

warnings.filterwarnings('ignore')

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
basedir = os.path.abspath(os.path.dirname(__file__))
outputSaveDir = basedir + '/output/picture/'  ###########加进来
if not os.path.exists(outputSaveDir):
    os.makedirs(outputSaveDir)

# os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
# basedir = os.path.abspath(os.path.dirname(__file__))
# # outputSaveDir = basedir + '/output/'
# outputSaveDir = basedir + '/output/picture/'     ###########加进来
# if not os.path.exists(outputSaveDir + 'picture/'):
#     os.makedirs(outputSaveDir + 'picture/')

config_path = "predict_map.json"
with open(config_path, 'r', encoding='utf-8-sig') as f:
    params = json.load(f)

class_name = str(params["class_name"])
n_class = int(len(class_name.split(',')))
if "background" not in class_name:
    n_class += 1
model_name = params["model_name"]
dataset_id = params["dataset_id"]

# zhu conf = input()
# zhu params_estimate = json.loads(conf)

# config_estimate_path = "traincfgPre.json"
# with open(config_estimate_path, 'r', encoding='utf-8') as f:
#     params_estimate = json.load(f)

# zhu image_path = params_estimate["image_path"]

# 图片大小
load_size = params["load_size"].split(',')
load_size[0] = round(float(load_size[0]) / 32) * 32
load_size[1] = round(float(load_size[1]) / 32) * 32
if load_size[1] > load_size[0]:
    load_size[1] = load_size[0]
else:
    load_size[0] = load_size[1]

# zhu weight_path = basedir + "/weight/"
# zhu weights_file = weight_path + model_name + ".th"
weights_file = '/home/zhulifu/temp/pytorch-nested-unet-master/models_old/model_old.pth'

BATCHSIZE_PER_CARD = 2

'''
device_ids = []
gpu_num = int(params_estimate['gpu_num'])
if gpu_num == 0:
    pass  # for CPU
else:
    for i in range(0, gpu_num):
        device_ids.append(i)
'''

score_threshold = 0.3
# zhu s3Client = aiUtils.s3GetImg(datasetId=dataset_id)

labels = params['label']
labels = eval(labels)
rgb_value = {}
acval_realval = {}
background_value = [0]
class_map = {}
for i, val in enumerate(labels):
    for key in val.keys():
        if key == "class_color":
            color_ = val[key]
            rgb_va = list(map(int, color_.split(',')))
            rgb = tuple(list(map(int, color_.split(','))))
        elif key == "class_name":
            cls_name = val[key]
        elif key == "class_value":
            value = int(val[key])
            trainValue = int(i)
        else:
            continue
    if rgb and value >= 0:
        rgb_value[rgb] = value
        acval_realval[value] = trainValue
        class_map[cls_name] = rgb_va

background_value = class_map['background']

rgb_value = {}
acval_realval = {}
background_value = [0]
class_color = {}
class_value_map = {}
for i, val in enumerate(labels):
    for key in val.keys():
        if key == "class_color":
            color_ = val[key]
            rgb_va = list(map(int, color_.split(',')))
            rgb = tuple(list(map(int, color_.split(','))))
        elif key == "class_name":
            cls_name = val[key]
        elif key == "class_value":
            value = int(val[key])
            trainValue = int(i)
        elif key == "class_title":
            cls_title = val[key]
        else:
            continue

    if rgb and value >= 0:
        rgb_value[rgb] = value
        acval_realval[value] = trainValue
        class_value_map[trainValue] = cls_title
        class_color[trainValue] = 'rgb' + str(rgb)
del class_value_map[0]
del class_color[0]


def generateOvrFile(src_file, update=True):
    """
    生产金字塔文件
    :param src_file:
    :param update:
    :return:
    """
    # import gdal
    print("generateOvrFile process file: {0}".format(src_file))
    if not os.path.exists(src_file):
        print("generateOvrFile: {0} is not exist".format(src_file))
        return
    _ovr_file = "{}.ovr".format(src_file)
    if os.path.exists(_ovr_file):
        if update:
            os.remove(_ovr_file)
        else:
            return
    cmd_str = "gdaladdo -r NEAREST -ro --config COMPRESS_OVERVIEW LZW {0}".format(src_file)
    return os.system(cmd_str)


class TTAFrame():

    def uint16to8(self, data, lower_percent=0.001, higher_percent=99.999):
        out = np.zeros_like(data).astype(np.uint8)  # .astype(np.float)
        n = 3
        for i in range(n):
            a = 0  # np.min(band)
            b = 255  # np.max(band)
            c = np.percentile(data[:, :, i], lower_percent)
            d = np.percentile(data[:, :, i], higher_percent)
            t = a + (data[:, :, i] - c) * (b - a) / (d - c)
            t[t < a] = a
            t[t > b] = b
            out[:, :, i] = t
        return out

    def classToRGB(self, mask, height, width, rgb_value, acval_realval):
        colmap = np.zeros(shape=(height, width, 3)).astype(np.uint8)
        class_rgb = dict(zip(rgb_value.values(), rgb_value.keys()))
        for class_v in class_rgb.keys():
            val = acval_realval[class_v]
            indices = np.where(mask == val)
            colmap[indices[0].tolist(),
            indices[1].tolist(), :] = np.array(class_rgb[class_v])
        return colmap

    def pre_img_clip(self, net, imagepath, evalmode=True):
        self.net = net
        # if evalmode:
        # self.net.eval()
        # zhu gdal = s3Client.gdal

        ogr.RegisterAll()
        gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
        gdal.SetConfigOption("SHAPE_ENCODING", "CP936")

        # gdal读取图片
        # s3文件需要转换成gdal可读的虚拟文件路径
        '''zhu
        imageFilePrefix = imagepath.split("/")[0]
        if imageFilePrefix == "s3:":
            imagepath = imagepath.replace("s3://", "")
            imagepath = f"/vsis3/{imagepath}"
            '''
        imagepath = './premap/pre.tif'
        dataset = gdal.Open(imagepath)
        width = dataset.RasterXSize  # 获取数据宽度
        height = dataset.RasterYSize  # 获取数据高度
        outbandsize = dataset.RasterCount  # 获取数据波段数

        # 裁切大小，活动重叠的间隔
        cut_size = int(load_size[0])
        bias = int(cut_size / 8)

        # 滑动裁切
        x_idx = range(0, width, cut_size - bias)
        y_idx = range(0, height, cut_size - bias)

        # 输出output
        rslt_mask = np.zeros((height, width), dtype=np.uint8)
        # self.net = net

        for y_start in y_idx:  # 沿着纵向
            for x_start in x_idx:  # 沿着横向（先横后纵）
                x_stop = x_start + cut_size
                if x_stop > width:
                    x_start = width - cut_size
                y_stop = y_start + cut_size
                if y_stop > height:
                    y_start = height - cut_size

                cut_width = cut_size
                cut_height = cut_size
                switch_flag = 0
                if x_start < 0 and y_start >= 0:
                    x_start = 0
                    x_stop = width
                    cut_width = width
                    switch_flag = 1
                elif x_start >= 0 and y_start < 0:
                    y_start = 0
                    y_stop = height
                    cut_height = height
                    switch_flag = 2
                elif x_start < 0 and y_start < 0:
                    x_start = 0
                    x_stop = width
                    cut_width = width
                    y_start = 0
                    y_stop = height
                    cut_height = height
                    switch_flag = 3

                croped_img = dataset.ReadAsArray(x_start, y_start, cut_width, cut_height)

                croped_img = croped_img.transpose(1, 2, 0)
                if outbandsize > 3:
                    croped_img = croped_img[:, :, 0:3]

                if switch_flag == 1:
                    temp = np.zeros((croped_img.shape[0], cut_size, croped_img.shape[2]), dtype=np.uint8)
                    # temp = np.zeros((cut_size, croped_img.shape[1], croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                elif switch_flag == 2:
                    # temp = np.zeros((croped_img.shape[0], cut_size, croped_img.shape[2]), dtype=np.uint8)
                    temp = np.zeros((cut_size, croped_img.shape[1], croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                elif switch_flag == 3:
                    temp = np.zeros((cut_size, cut_size, croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp

                img = (croped_img / 255.0).transpose(2, 0, 1).astype(np.float32)
                img = torch.from_numpy(img).unsqueeze(0)

                with torch.no_grad():
                    img = Variable(torch.Tensor(img).cuda())
                    outputs = self.net(img)

                val_mask = np.argmax(outputs[0].data.cpu().numpy(), axis=-1)
                # pred = np.argmax(val_mask, axis=0)
                pred = val_mask.astype(np.uint8)
                print(pred)
                rslt_mask[y_start:y_stop, x_start:x_stop] = pred[0:cut_height, 0:cut_width]
        # 保存图片
        pred = self.classToRGB(rslt_mask, height, width, rgb_value, acval_realval)
        return pred

    def predict_clip_shp(self, net, imagepath, outputPath, evalmode=True):
        self.net = net
        if evalmode:
            self.net.eval()

        # gdal读取数据
        # zhu gdal = s3Client.gdal

        ogr.RegisterAll()
        gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
        gdal.SetConfigOption("SHAPE_ENCODING", "CP936")

        # gdal读取图片
        # s3文件需要转换成gdal可读的虚拟文件路径
        ''' zhu
        imageFilePrefix = imagepath.split("/")[0]
        if imageFilePrefix == "s3:":
            imagepath = imagepath.replace("s3://", "")
            imagepath = f"/vsis3/{imagepath}"
            '''
        imagepath = './premap/pre.tif'
        dataset = gdal.Open(imagepath)
        if not dataset:
            print('not get image data from : ' + imagepath)
            exit(1)
        width = dataset.RasterXSize  # 获取数据宽度
        height = dataset.RasterYSize  # 获取数据高度
        outbandsize = dataset.RasterCount  # 获取数据波段数
        geo_trans = dataset.GetGeoTransform()
        projection = dataset.GetProjection()

        # 裁切大小，活动重叠的间隔
        cut_size = int(load_size[0])
        bias = int(cut_size / 8)

        # 滑动裁切
        x_idx = range(0, width, cut_size - bias)
        y_idx = range(0, height, cut_size - bias)

        band_count = 3
        # 输出output
        format = "GTiff"
        tiff_driver = gdal.GetDriverByName(format)
        output_ds = tiff_driver.Create(outputPath, width, height,
                                       band_count, gdalconst.GDT_Byte)
        output_ds.SetGeoTransform(geo_trans)
        output_ds.SetProjection(projection)
        # rslt_pred = np.zeros((height, width), dtype=np.uint8)
        for band_index in range(band_count):
            output_ds.GetRasterBand(band_index + 1).SetNoDataValue(background_value[band_index])

        # self.net = net

        total_progress = len(x_idx) * len(y_idx)
        count = 0
        process = "%.1f%%" % (0 * 100)
        print("[ROUTINE] {process}".format(process=process), flush=True)
        i = 0
        for y_start in y_idx:  # 沿着纵向
            for x_start in x_idx:  # 沿着横向（先横后纵）
                x_stop = x_start + cut_size
                if x_stop > width:
                    x_start = width - cut_size
                y_stop = y_start + cut_size
                if y_stop > height:
                    y_start = height - cut_size

                cut_width = cut_size
                cut_height = cut_size
                switch_flag = 0
                if x_start < 0 and y_start >= 0:
                    x_start = 0
                    x_stop = width
                    cut_width = width
                    switch_flag = 1
                elif x_start >= 0 and y_start < 0:
                    y_start = 0
                    y_stop = height
                    cut_height = height
                    switch_flag = 2
                elif x_start < 0 and y_start < 0:
                    x_start = 0
                    x_stop = width
                    cut_width = width
                    y_start = 0
                    y_stop = height
                    cut_height = height
                    switch_flag = 3

                croped_img = dataset.ReadAsArray(x_start, y_start, cut_width, cut_height)

                croped_img = croped_img.transpose(1, 2, 0)
                if outbandsize > 3:
                    croped_img = croped_img[:, :, 0:3]

                if switch_flag == 1:
                    temp = np.zeros((croped_img.shape[0], cut_size, croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                elif switch_flag == 2:
                    temp = np.zeros((cut_size, croped_img.shape[1], croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                elif switch_flag == 3:
                    temp = np.zeros((cut_size, cut_size, croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                cv2.imwrite("img_c.jpg", croped_img)

                val_transform = Compose([
                    # transforms.Resize(config['input_h'], config['input_w']),
                    transforms.Normalize(),
                ])
                img = val_transform(image=croped_img)['image']
                img = img.astype('float32') / 255

                # img = (croped_img/255.0).astype(np.float32)

                img = img.transpose(2, 0, 1)
                img = torch.from_numpy(img).unsqueeze(0).cuda()
                with torch.no_grad():
                    outputs = self.net(img)
                outputs = torch.sigmoid(outputs).cpu().numpy()
                print("333: ", outputs.shape)
                # print(outputs)
                outputs = np.squeeze(outputs)

                print("555: ", outputs.shape)

                outputs_save = (outputs * 255).astype('uint8')
                i = i + 1
                cv2.imwrite("./xiao/imgoutputs_c" + str(i) + ".jpg", outputs_save)
                # print(outputs)
                pred = outputs_save[0:cut_height, 0:cut_width]

                if len(rgb_value) > 0 and len(acval_realval) > 0:
                    re_pred = self.classToRGB(pred, cut_height, cut_width, rgb_value, acval_realval)
                    for band_index in range(3):
                        output_ds.GetRasterBand(band_index + 1).WriteArray(re_pred[:, :, band_index], x_start, y_start)
                else:
                    output_ds.GetRasterBand(1).WriteArray(pred, x_start, y_start)

                del (img, outputs_save)

                count += 1
                now_progress = "%.1f%%" % ((count / total_progress) * 100)
                print("[ROUTINE] {process}".format(process=now_progress), flush=True)
        return outputs

    def predict_clip_gdal(self, net, imagepath, outputPath):
        self.net = net
        self.net.eval()
        # gdal读取数据
        # gdal = s3Client.gdal

        ogr.RegisterAll()
        gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
        gdal.SetConfigOption("SHAPE_ENCODING", "CP936")

        # gdal读取图片
        # s3文件需要转换成gdal可读的虚拟文件路径
        '''zhu
        imageFilePrefix = imagepath.split("/")[0]
        if imageFilePrefix == "s3:":
            imagepath = imagepath.replace("s3://", "")
            imagepath = f"/vsis3/{imagepath}"
            '''
        # imagepath = './premap/pre.tif'
        dataset = gdal.Open(imagepath)
        if not dataset:
            print('not get image data from : ' + imagepath)
        im_proj = dataset.GetProjection()  # 获取投影信息
        if im_proj:
            srs_ = osr.SpatialReference()
            srs_.SetWellKnownGeogCS('WGS84')
            dataset = gdal.AutoCreateWarpedVRT(dataset, None, srs_.ExportToWkt())  # , gdal.GRA_Bilinear)
            print(dataset.GetProjection())

        width = dataset.RasterXSize  # 获取数据宽度
        height = dataset.RasterYSize  # 获取数据高度
        outbandsize = dataset.RasterCount  # 获取数据波段数
        geo_trans = dataset.GetGeoTransform()
        print(geo_trans)
        projection = dataset.GetProjection()
        print(projection)

        # 裁切大小，活动重叠的间隔
        cut_size = int(load_size[0])
        bias = int(cut_size / 4)

        # 滑动裁切
        x_idx = range(0, width, cut_size - bias)
        y_idx = range(0, height, cut_size - bias)

        band_count = 3
        # 输出output
        format = "GTiff"
        tiff_driver = gdal.GetDriverByName(format)
        print(outputPath)
        print(width)
        print(height)
        print(band_count)
        print(gdalconst.GDT_Byte)
        output_ds = tiff_driver.Create(outputPath, width, height, band_count, gdalconst.GDT_Byte)
        output_ds.SetGeoTransform(geo_trans)
        output_ds.SetProjection(projection)
        for band_index in range(band_count):
            output_ds.GetRasterBand(band_index + 1).SetNoDataValue(background_value[0])

        # 单波段图片
        format = "GTiff"
        tiff_driver2 = gdal.GetDriverByName(format)
        output_ds_tmp = tiff_driver2.Create(basedir + '/pred_tmp.tif', width, height,
                                            1, gdalconst.GDT_Byte)
        if not projection:
            im_geotrans_ = (geo_trans[0], geo_trans[1], geo_trans[2], geo_trans[3], geo_trans[4], -1.0)
            output_ds_tmp.SetGeoTransform(im_geotrans_)
        else:
            output_ds_tmp.SetGeoTransform(geo_trans)
        output_ds_tmp.SetProjection(projection)
        output_ds_tmp.GetRasterBand(1).SetNoDataValue(background_value[0])

        # self.net = net

        total_progress = len(x_idx) * len(y_idx)
        count = 0
        process = "%.1f%%" % (0 * 100)
        print("[ROUTINE] {process}".format(process=process), flush=True)
        i = 0

        for y_start in y_idx:  # 沿着纵向
            for x_start in x_idx:  # 沿着横向（先横后纵）
                x_stop = x_start + cut_size
                if x_stop > width:
                    x_start = width - cut_size
                y_stop = y_start + cut_size
                if y_stop > height:
                    y_start = height - cut_size

                cut_width = cut_size
                cut_height = cut_size
                switch_flag = 0
                if x_start < 0 and y_start >= 0:
                    x_start = 0
                    x_stop = width
                    cut_width = width
                    switch_flag = 1
                elif x_start >= 0 and y_start < 0:
                    y_start = 0
                    y_stop = height
                    cut_height = height
                    switch_flag = 2
                elif x_start < 0 and y_start < 0:
                    x_start = 0
                    x_stop = width
                    cut_width = width
                    y_start = 0
                    y_stop = height
                    cut_height = height
                    switch_flag = 3

                croped_img = dataset.ReadAsArray(x_start, y_start, cut_width, cut_height)

                croped_img = croped_img.transpose(1, 2, 0)

                if switch_flag == 1:
                    temp = np.zeros((croped_img.shape[0], cut_size, croped_img.shape[2]), dtype=np.uint8)
                    # temp = np.zeros((cut_size, croped_img.shape[1], croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                elif switch_flag == 2:
                    # temp = np.zeros((croped_img.shape[0], cut_size, croped_img.shape[2]), dtype=np.uint8)
                    temp = np.zeros((cut_size, croped_img.shape[1], croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp
                elif switch_flag == 3:
                    temp = np.zeros((cut_size, cut_size, croped_img.shape[2]), dtype=np.uint8)
                    temp[0:croped_img.shape[0], 0:croped_img.shape[1], :] = croped_img
                    croped_img = temp

                cv2.imwrite("img_c.jpg", croped_img)
                val_transform = Compose([
                    # transforms.Resize(config['input_h'], config['input_w']),
                    transforms.Normalize(),
                ])
                img = val_transform(image=croped_img)['image']
                # img = (croped_img / 255.0).astype(np.float32)
                img = img.astype('float32') / 255

                img = img.transpose(2, 0, 1)
                img = torch.from_numpy(img).unsqueeze(0)  #.cuda()
                with torch.no_grad():
                    outputs = self.net(img)
                outputs = torch.sigmoid(outputs).cpu().numpy()
                # print("333: ", outputs.shape)
                # print(outputs)
                outputs = np.squeeze(outputs)
                # print("555: ", outputs.shape)
                outputs_save = (outputs * 255).astype('uint8')
                i = i + 1
                # cv2.imwrite("./xiao/imgoutputs_c" + str(i) + ".jpg",outputs_save)

                pred = outputs[0:cut_height, 0:cut_width]
                output_ds_tmp.GetRasterBand(1).WriteArray(pred, x_start, y_start)

                if len(rgb_value) > 0 and len(acval_realval) > 0:
                    pred = self.classToRGB(pred, cut_height, cut_width, rgb_value, acval_realval)
                    for band_index in range(3):
                        output_ds.GetRasterBand(band_index + 1).WriteArray(pred[:, :, band_index], x_start, y_start)
                else:
                    output_ds.GetRasterBand(1).WriteArray(pred, x_start, y_start)

                del (img)
                count += 1
                now_progress = "%.1f%%" % ((count / total_progress) * 100)
                print("[ROUTINE] {process}".format(process=now_progress), flush=True)
                # rslt_pred[y_start:y_stop,x_start:x_stop] = rslt_pred[y_start:y_stop,x_start:x_stop] | pred[0:cut_height,0:cut_width]

        # rslt_pred = self.classToRGB(rslt_pred,height,width,rgb_value,actVal_val)

        # return rslt_pred
        # shp_to_geojson(gdal, outputFile[:-4] + ".shp", outputFile[:-4] + ".json",projection)
        del (output_ds_tmp, output_ds)
        return projection


def tif2shp(outFile, outputPath):
    outdataset = gdal.Open(outFile)
    inband = outdataset.GetRasterBand(1)
    prj = osr.SpatialReference()
    prj.ImportFromWkt(outdataset.GetProjection())

    outshp = outputPath[:-4] + ".shp"
    drv = ogr.GetDriverByName("ESRI Shapefile")
    if os.path.exists(outshp):
        drv.DeleteDataSource(outshp)
    Polygon = drv.CreateDataSource(outshp)
    Poly_layer = Polygon.CreateLayer(outputPath[:-4], srs=prj, geom_type=ogr.wkbMultiPolygon)

    newField = ogr.FieldDefn('value', ogr.OFTReal)
    Poly_layer.CreateField(newField)
    gdal.FPolygonize(inband, None, Poly_layer, 0)
    Polygon.SyncToDisk()
    Polygon = None
    del outdataset


def shp_to_geojson(gdal, vector, output, projection):
    print("convert to geojson start........")
    # 打开矢量图层
    gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "YES")
    gdal.SetConfigOption("SHAPE_ENCODING", "GBK")
    shp_ds = ogr.Open(vector)
    shp_lyr = shp_ds.GetLayer()

    # 创建结果Geojson
    baseName = os.path.basename(output)
    out_driver = ogr.GetDriverByName('GeoJSON')
    out_ds = out_driver.CreateDataSource(output)
    if out_ds.GetLayer(baseName):
        out_ds.DeleteLayer(baseName)
    out_lyr = out_ds.CreateLayer(baseName, shp_lyr.GetSpatialRef())
    # out_lyr.CreateFields(shp_lyr.schema)
    # 新增
    oord_fld = ogr.FieldDefn('FieldId', ogr.OFTReal)
    oord_fld.SetPrecision(3)
    out_lyr.CreateField(oord_fld)
    # 新增
    oord_Name = ogr.FieldDefn('FieldName', ogr.OFTString)
    oord_Name.SetPrecision(3)
    out_lyr.CreateField(oord_Name)
    # 新增
    oord_score = ogr.FieldDefn('scroe', ogr.OFTReal)
    oord_score.SetPrecision(3)
    out_lyr.CreateField(oord_score)
    # 新增
    oord_area = ogr.FieldDefn('Area', ogr.OFTReal)
    oord_area.SetPrecision(3)
    out_lyr.CreateField(oord_area)
    # 新增
    oord_color = ogr.FieldDefn('Color', ogr.OFTString)
    oord_color.SetPrecision(3)
    out_lyr.CreateField(oord_color)
    # 新增单位
    oord_unit = ogr.FieldDefn('Unit', ogr.OFTString)
    oord_unit.SetPrecision(3)
    out_lyr.CreateField(oord_unit)

    out_feat = ogr.Feature(out_lyr.GetLayerDefn())

    # 生成结果文件
    i = 0
    for feature in shp_lyr:
        isNone = True
        # out_feat.SetGeometry(feature.geometry())
        gometry = feature.geometry()
        for j in range(feature.GetFieldCount()):
            if int(feature.GetField(j)) == 0:
                isNone = False
                continue
            # out_feat.SetField(j, feature.GetField(j))
            out_feat.SetField(j, i)
            out_feat.SetField(j + 1, class_value_map[int(feature.GetField(j))])
            out_feat.SetField(j + 2, None)
            area = gometry.GetArea()
            unit = None
            if projection:
                unit = 'm²'
                # if projection == 1:
                #     area = round(math.fabs(area / 2) * 9101160000.085981, 2)

                area = round(math.fabs(area / 2) * 9101160000.085981, 2)
            out_feat.SetField(j + 3, round(area, 2))
            out_feat.SetField(j + 4, class_color[int(feature.GetField(j))])
            out_feat.SetField(j + 5, unit)
            i += 1
        if (isNone):
            out_lyr.CreateFeature(out_feat)
        # out_lyr.CreateFeature(out_feat)

    del out_ds
    del shp_ds
    print("convert to geojson Success........")


class PredictModel:
    def __init__(self):
        self.cuda = torch.cuda.is_available()

        with open('models/datasets_NestedUNet_woDS/config.yml', 'r') as f:
            config = yaml.load(f, Loader=yaml.FullLoader)
        for key in config.keys():
            print('%s: %s' % (key, str(config[key])))
            print('-' * 20)
            print("=> creating model %s" % config['arch'])
        self.model = archs.__dict__[config['arch']](config['num_classes'],
                                                    config['input_channels'],
                                                    config['deep_supervision'])

        #   CPU上直接进行并行处理
        self.model = torch.nn.DataParallel(self.model)

        device = torch.device('cuda' if self.cuda else 'cpu')
        weights_file = 'models/datasets_NestedUNet_woDS/model1024×1024.pth'
        self.model.load_state_dict(torch.load(weights_file, map_location=device))
        if self.cuda:
            self.model = self.model.cuda()
        if torch.cuda.device_count() > 1:
            self.model = torch.nn.DataParallel(self.model)

    # names和meta为可选参数，预留参数。函数返回类型是ndarray
    def predict_clip(self, imagePath, outputpath):
        solver = TTAFrame()
        # outputs = solver.predict_clip_shp(self.model, imagePath,outputpath)
        outputs = solver.predict_clip_gdal(self.model, imagePath, outputpath)
        # skio.imsave(outputSaveDir + 'picture/' + filename + ".png", outputs)
        return outputs


def bytes(bytes):
    if bytes < 1024:  # 比特
        bytes = str(round(bytes, 2)) + ' B'  # 字节
    elif bytes >= 1024 and bytes < 1024 * 1024:
        bytes = str(round(bytes / 1024, 2)) + ' KB'  # 千字节
    elif bytes >= 1024 * 1024 and bytes < 1024 * 1024 * 1024:
        bytes = str(round(bytes / 1024 / 1024, 2)) + ' MB'  # 兆字节
    elif bytes >= 1024 * 1024 * 1024 and bytes < 1024 * 1024 * 1024 * 1024:
        bytes = str(round(bytes / 1024 / 1024 / 1024, 2)) + ' GB'  # 千兆字节
    elif bytes >= 1024 * 1024 * 1024 * 1024 and bytes < 1024 * 1024 * 1024 * 1024 * 1024:
        bytes = str(round(bytes / 1024 / 1024 / 1024 / 1024, 2)) + ' TB'  # 太字节
    elif bytes >= 1024 * 1024 * 1024 * 1024 * 1024 and bytes < 1024 * 1024 * 1024 * 1024 * 1024 * 1024:
        bytes = str(round(bytes / 1024 / 1024 / 1024 / 1024 / 1024, 2)) + ' PB'  # 拍字节
    elif bytes >= 1024 * 1024 * 1024 * 1024 * 1024 * 1024 and bytes < 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024:
        bytes = str(round(bytes / 1024 / 1024 / 1024 / 1024 / 1024 / 1024, 2)) + ' EB'  # 艾字节
    return bytes


fileKey = ['.tif', '.json', '.cpg', '.dbf', '.prj', '.shx', '.shp', '.ovr']
shpFileKey = ['.cpg', '.dbf', '.prj', '.shx', '.shp']

if __name__ == '__main__':
    start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    # zhu log = {"create_time": start_time, "epochs": [], "end_time": ""}

    ######################################################################
    # zhu log_new = {"zipOutFile": '/' + '/'.join(outputSaveDir.split('/')[2:]) + "result.zip", "total_output_size": "","task_list": []}
    allSizeInt = 0
    allSize = 0
    #####################################################################################
    # images = image_path.split(",")   by Mr.Yang
    # 打开图片并裁剪
    test_img_path = 'F:/data/wuxi-GF2-3/subImgs/rawImgs/notSamples'
    images = glob.glob(test_img_path + '/*.tif')
    image_size = int(len(images))

    model = PredictModel()
    fileList = []
    print("image size: ", image_size)
    for index in range(image_size):
        process = float((index + 1) / image_size)  #####加进来
        # zhu log_new["process"] = process  #####加进来
        tmpfilename = os.path.basename(images[index])
        if 'img13_3.tif' not in tmpfilename:
            continue
        filename, extension = os.path.splitext(tmpfilename)
        # 重命名，例如： 1_xxx_pred#####加进来
        filename = str(index + 1) + "_" + filename + "_pred"  #####加进来
        outputFile = outputSaveDir + filename + '.tif'  #####加进来

        projection = model.predict_clip(images[index], outputFile)
        generateOvrFile(outputFile)
        tif2shp(basedir + '/pred_tmp.tif', outputFile[:-4] + ".shp")
        shp_to_geojson(gdal, outputFile[:-4] + ".shp", outputFile[:-4] + ".json", projection)
        # model.predict_clip(images[index],outputFile)
        fileList.append(outputFile)
        # fileList.append(outputSaveDir + 'picture/' + filename + ".tif")

        ############################################################
        task_list = {"output_size": "", "input": "", "output": []}  ######加进来
        # 输入图片

        task_list["input"] = images[index]
        # 获取shp
        sizeInt = int(0)
        sizeStr = 0
        # task_list["input"] = images[index]
        for key in fileKey:
            outFileName = None
            if os.path.exists(outputFile + key):
                outFileName = outputFile + key
            elif os.path.exists(outputFile[:-4] + key):
                outFileName = outputFile[:-4] + key
            else:
                continue
            if os.path.exists(outFileName):
                fileSize = os.stat(outFileName).st_size
                if fileSize > 0:
                    sizeInt = sizeInt + int(fileSize)
                    fileSize = bytes(fileSize)
                    sizeStr = bytes(sizeInt)
                # zhu output_log = {"name": "", "size": ""}
                print("outputs files: ", outFileName)
                # zhu output_log["name"] = '/' + '/'.join(outFileName.split('/')[2:])
                # zhu output_log["size"] = fileSize
                # zhu task_list["output"].append(output_log)

        allSizeInt += sizeInt
        allSize = bytes(allSizeInt)

        task_list = {"output_size": "", "input": "", "output": []}
        task_list["output_size"] = sizeStr
        # zhu log_new['task_list'].append(task_list)
        # zhu log_new['total_output_size'] = allSize
        # zhu trainlog = json.dumps(log_new, indent=4)
        # zhu with open(basedir + '/output/trainlog' + '.json', 'w', encoding='utf-8') as log_file:
        # zhu    log_file.write(trainlog)
        ##############################################################
        # log["epochs"].append({"epoch": index + 1, "image": '/output/picture/' + filename + ".tif"})
        # if index == image_size - 1:
        #     end_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        #     log["end_time"] = end_time
        # trainlog = json.dumps(log, indent=4)
        # with open(basedir + '/output/trainlog' + '.json', 'w', encoding='utf-8') as log_file:
        #     log_file.write(trainlog)
        print("[Process: {process}]".format(process=str(index + 1) + '/' + str(image_size)))

    # 压缩矢量文件，生成矢量文件时，设置文件名_zip
    zf = zipfile.ZipFile(outputSaveDir + 'result.zip', "w", zipfile.zlib.DEFLATED)
    fileList = glob.glob(outputSaveDir + '*.*')
    for tar in fileList:
        fileAllName = os.path.basename(tar)
        if fileAllName[-4:] in shpFileKey:
            zf.write(tar, fileAllName)
    zf.close()
