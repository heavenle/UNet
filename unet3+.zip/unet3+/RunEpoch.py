import os
import pdb
import time
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
from collections import OrderedDict
import numpy as np
import torch
from tqdm import tqdm
# load metrics
from metrics import Metrics,Evaluator,iou_score
from utils import AverageMeter
import DrawMask


def train(config, train_loader, model, criterion, optimizer, device):

    # avg_meters = {'loss': AverageMeter(),
    #               'iou': AverageMeter(),
    #               'bce_loss': AverageMeter(),
    #               'msssim_loss': AverageMeter(),
    #               'iou_loss': AverageMeter()
    #               }
    # evaluator = Evaluator(config['num_classes'])
    # train_metrics = Metrics(config['num_classes'])

    model.train()
    # -- 进度条
    pbar = tqdm(total=len(train_loader))
    # -- 初始化Unet3+的初始值。
    msssim_loss = 0
    bce_loss = 0
    iou_loss = 0

    for input, target, _ in train_loader:

        if config['cuda']==True:
            input = input.to(device)
            target = target.to(device)

        # compute output
        if config['deep_supervision']:
            if config['arch'] == 'UNet_3Plus':
                d1, d2, d3, d4, d5 = model(input)
                msssim_loss = 0
                bce_loss = 0
                iou_loss = 0
                for output in [d1, d2, d3, d4, d5]:
                    msssim_loss += criterion['MSSSIMLoss'](output, target)
                    bce_loss += criterion['BceLoss'](output, target)
                    iou_loss += criterion['iouLoss'](output, target)
                bce_loss = bce_loss/5
                msssim_loss = 1 - msssim_loss/5
                iou_loss = iou_loss/5
                loss = bce_loss + msssim_loss + iou_loss

                # iou = iou_score(d1, target, flag=config['arch'])
            else:
                pass
                # outputs = model(input)
                # loss = 0
                # for output in outputs:
                #     loss += criterion(output, target)
                # loss /= len(outputs)
                # iou = iou_score(outputs[-1], target)
        else:
            if config['arch'] == 'UNet_2Plus':
                output = model(input)
                bce_loss = criterion['BceLoss'](output, target)
                iou_loss = criterion['iouLoss'](output, target)
                loss = bce_loss + iou_loss
                # iou = iou_score(output, target)
            elif config['arch'] == 'UNet_3Plus':
                output = model(input)
                bce_loss = criterion['BceLoss'](output, target)
                iou_loss = criterion['iouLoss'](output, target)
                loss = bce_loss + iou_loss
            else:
                # output = model(input)
                # loss = criterion(output, target)
                pass

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        # if config['cuda']:
        #     if config['deep_supervision']:
        #         # pred = output.data.cpu().numpy()
        #         d1 = d1.data.cpu().numpy()
        #     else:
        #         pred = output.data.cpu().numpy()
        # else:
        #     if config['deep_supervision']:
        #         # pred=output.numpy()
        #         d1 = d1.numpy()
        #     else:
        #         pred = output.data.cpu().numpy()
        #
        # target = target.cpu().numpy()
        #
        # # 计算指标。
        # if config['deep_supervision']:
        #     for batch_num in range(0, d1.shape[0]):
        #         pred = np.argmax(d1[batch_num].transpose(1, 2, 0), 2)
        #         gt = np.argmax(target[batch_num].transpose(1, 2, 0), 2)
        #         evaluator.add_batch(gt, pred)
        #         pred = np.rint(pred).astype(int)
        #         gt = gt.astype(int)
        #         train_metrics.add(gt, pred)
        # else:
        #     for batch_num in range(0, pred.shape[0]):
        #         out = np.argmax(pred[batch_num].transpose(1, 2, 0), 2)
        #         gt = np.argmax(target[batch_num].transpose(1, 2, 0), 2)
        #         evaluator.add_batch(gt, out)
        #         out = np.rint(out).astype(int)
        #         gt = gt.astype(int)
        #         train_metrics.add(gt, out)

        # # 更新指标
        # avg_meters['loss'].update(loss.item(), input.size(0))
        # avg_meters['iou'].update(iou, input.size(0))
        # avg_meters['bce_loss'].update(bce_loss.item(), input.size(0))
        # avg_meters['msssim_loss'].update(msssim_loss.item(), input.size(0))
        # avg_meters['iou_loss'].update(iou_loss.item(), input.size(0))
        #
        # postfix = OrderedDict([
        #     ('loss', avg_meters['loss'].avg),
        #     ('iou', avg_meters['iou'].avg),
        #     ('bce_loss', avg_meters['bce_loss'].avg),
        #     ('msssim_loss', avg_meters['msssim_loss'].avg),
        #     ('iou_loss', avg_meters['iou_loss'].avg)
        # ])

        # pbar.set_postfix(postfix)
        pbar.update(1)

    # del d1, d2, d3, d4, d5, pred, target
    # del d1, d2, d3, d4, d5, target
    pbar.close()

    # train_epoch_loss = avg_meters['loss'].avg
    # train_epoch_pr = train_metrics.get_precision()
    # train_epoch_re = train_metrics.get_recall()
    # train_epoch_fs = train_metrics.get_f_score()
    # train_epoch_iou = train_metrics.get_fg_iou()
    # train_epoch_pr_mean = sum(train_epoch_pr) / len(train_epoch_pr)
    # train_epoch_re_mean = sum(train_epoch_re) / len(train_epoch_re)
    # train_epoch_fs_mean = sum(train_epoch_fs) / len(train_epoch_fs)
    # train_epoch_iou_mean = sum(train_epoch_iou) / len(train_epoch_iou)
    #
    # Acc = evaluator.Pixel_Accuracy()   #score
    # Acc_class = evaluator.Pixel_Accuracy_Class()
    # mIoU = evaluator.Mean_Intersection_over_Union()
    # FWIoU = evaluator.Frequency_Weighted_Intersection_over_Union()
    #
    # print('acc={:.4f}    acc_class={:.4f}   miou={:.4f} fwiou={:.4f}'.format(Acc,Acc_class,mIoU,FWIoU))
    # print('pre={:.4f}    fs={:.4f} recall={:.4f}    miou={:.4f}'.format(train_epoch_pr_mean,train_epoch_fs_mean,train_epoch_re_mean,train_epoch_iou_mean))
    # return OrderedDict([('loss', avg_meters['loss'].avg),
    #                     ('iou', avg_meters['iou'].avg),
    #                     ('Acc',Acc),
    #                     ('Acc_class',Acc_class),
    #                     ('mIoU',mIoU),
    #                     ('FWIoU',FWIoU),
    #                     ('bce_loss', avg_meters['bce_loss'].avg),
    #                     ('msssim_loss', avg_meters['msssim_loss'].avg),
    #                     ('iou_loss', avg_meters['iou_loss'].avg)
    #                     ])


def validate(config, val_loader, model, criterion, device):

    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'bce_loss': AverageMeter(),
                  'msssim_loss': AverageMeter(),
                  'iou_loss': AverageMeter()
                  }
    # n_class=2
    evaluator = Evaluator(config['num_classes'])
    train_metrics = Metrics(config['num_classes'])

    # switch to evaluate mode
    model.eval()
    # -- 进度条
    pbar = tqdm(total=len(val_loader))
    # -- 初始化Unet3+的初始值。
    msssim_loss = 0
    bce_loss = 0
    iou_loss = 0
    with torch.no_grad():

        for input, target, ids in val_loader:
            if config['cuda'] == True:
                input = input.to(device)
                target = target.to(device)

            # compute output
            if config['deep_supervision']:
                if config['arch'] == 'UNet_3Plus':
                    d1, d2, d3, d4, d5 = model(input)
                    if str(config['draw_val_ids'][0]) in ids['img_id']:
                        batch_num = ids['img_id'].index(str(config['draw_val_ids'][0]))
                        DrawMask.draw_mask(d1[batch_num], config, 'pred')
                        DrawMask.draw_mask(target[batch_num], config, 'gt')
                    msssim_loss = 0
                    bce_loss = 0
                    iou_loss = 0
                    for output in [d1, d2, d3, d4, d5]:
                        msssim_loss += criterion['MSSSIMLoss'](output, target)
                        bce_loss += criterion['BceLoss'](output, target)
                        iou_loss += criterion['iouLoss'](output, target)
                    bce_loss = bce_loss / 5
                    msssim_loss = 1 - msssim_loss / 5
                    iou_loss = iou_loss / 5
                    loss = bce_loss + msssim_loss + iou_loss
                    iou = iou_score(d1, target, flag=config['arch'])

                else:
                    # outputs = model(input)
                    # loss = 0
                    # for output in outputs:
                    #     loss += criterion(output, target)
                    # loss /= len(outputs)
                    # iou = iou_score(outputs[-1], target)
                    pass
            else:
                if config['arch'] == 'UNet_2Plus':
                    output = model(input)
                    bce_loss = criterion['BceLoss'](output, target)
                    iou_loss = criterion['iouLoss'](output, target)
                    loss = bce_loss + iou_loss
                    if str(config['draw_val_ids'][0]) in ids['img_id']:
                        batch_num = ids['img_id'].index(str(config['draw_val_ids'][0]))
                        DrawMask.draw_mask(output[batch_num], config, 'pred')
                        DrawMask.draw_mask(target[batch_num], config, 'gt')

                elif config['arch'] == 'UNet_3Plus':
                    output = model(input)
                    bce_loss = criterion['BceLoss'](output, target)
                    iou_loss = criterion['iouLoss'](output, target)
                    loss = bce_loss + iou_loss
                    if str(config['draw_val_ids'][0]) in ids['img_id']:
                        batch_num = ids['img_id'].index(str(config['draw_val_ids'][0]))
                        DrawMask.draw_mask(output[batch_num], config, 'pred')
                        DrawMask.draw_mask(target[batch_num], config, 'gt')

                else:
                    # output = model(input)
                    # loss = criterion(output, target)
                    pass

            if config['cuda']:
                if config['deep_supervision']:
                    # pred = output.data.cpu().numpy()
                    d1 = d1.data.cpu().numpy()
                else:
                    pred = output.data.cpu().numpy()
            else:
                if config['deep_supervision']:
                    # pred=output.numpy()
                    d1 = d1.numpy()
                else:
                    pred = output.data.cpu().numpy()

            target = target.cpu().numpy()

            # 计算指标。
            if config['deep_supervision']:
                for batch_num in range(0, d1.shape[0]):
                    pred = np.argmax(d1[batch_num].transpose(1, 2, 0), 2)
                    gt = np.argmax(target[batch_num].transpose(1, 2, 0), 2)
                    evaluator.add_batch(gt, pred)
                    pred = np.rint(pred).astype(int)
                    gt = gt.astype(int)
                    train_metrics.add(gt, pred)
            else:
                for batch_num in range(0, pred.shape[0]):
                    out = np.argmax(pred[batch_num].transpose(1, 2, 0), 2)
                    gt = np.argmax(target[batch_num].transpose(1, 2, 0), 2)
                    evaluator.add_batch(gt, out)
                    out = np.rint(out).astype(int)
                    gt = gt.astype(int)
                    train_metrics.add(gt, out)

            # 更新指标
            avg_meters['loss'].update(loss.item(), input.size(0))
            # avg_meters['iou'].update(iou, input.size(0))
            # avg_meters['bce_loss'].update(bce_loss.item(), input.size(0))
            # avg_meters['msssim_loss'].update(msssim_loss.item(), input.size(0))
            # avg_meters['iou_loss'].update(iou_loss.item(), input.size(0))


            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                # ('iou', avg_meters['iou'].avg),
                # ('bce_loss', avg_meters['bce_loss'].avg),
                # ('msssim_loss', avg_meters['msssim_loss'].avg),
                # ('iou_loss', avg_meters['iou_loss'].avg)
            ])

            pbar.set_postfix(postfix)
            pbar.update(1)

        # del d1, d2, d3, d4, d5, pred, target
        pbar.close()

        train_epoch_loss = avg_meters['loss'].avg
        train_epoch_pr = train_metrics.get_precision()
        train_epoch_re = train_metrics.get_recall()
        train_epoch_fs = train_metrics.get_f_score()
        train_epoch_iou = train_metrics.get_fg_iou()
        train_epoch_pr_mean = sum(train_epoch_pr) / len(train_epoch_pr)
        train_epoch_re_mean = sum(train_epoch_re) / len(train_epoch_re)
        train_epoch_fs_mean = sum(train_epoch_fs) / len(train_epoch_fs)
        train_epoch_iou_mean = sum(train_epoch_iou) / len(train_epoch_iou)

        Acc = evaluator.Pixel_Accuracy()
        Acc_class = evaluator.Pixel_Accuracy_Class()
        mIoU = evaluator.Mean_Intersection_over_Union()
        FWIoU = evaluator.Frequency_Weighted_Intersection_over_Union()

        print('acc={:.4f}    acc_class={:.4f}   miou={:.4f} fwiou={:.4f}'.format(Acc, Acc_class, mIoU, FWIoU))
        print('pre={:.4f}    fs={:.4f} recall={:.4f}    miou={:.4f}'.format(train_epoch_pr_mean, train_epoch_fs_mean,
                                                                            train_epoch_re_mean, train_epoch_iou_mean))
    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('Acc',Acc),
                        ('Acc_class',Acc_class),
                        ('mIoU',mIoU),
                        ('FWIoU',FWIoU),
                        # ('bce_loss', avg_meters['bce_loss'].avg),
                        # ('msssim_loss', avg_meters['msssim_loss'].avg),
                        # ('iou_loss', avg_meters['iou_loss'].avg)
                        ])
