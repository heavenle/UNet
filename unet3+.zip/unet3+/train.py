import argparse
import os
import pdb
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
from collections import OrderedDict
from glob import glob
import opt
import pandas as pd
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml

from albumentations.augmentations import transforms
from albumentations.core.composition import Compose, OneOf
from sklearn.model_selection import train_test_split
from torch.optim import lr_scheduler
import RunEpoch
# 导入模型
import archs
from UNet_Version.models import UNet_3Plus, UNet_2Plus

# 导入损失
import losses
from UNet_Version.loss import msssimLoss, bceLoss, iouLoss, FocalLoss

# 导入数据迭代器
from dataset import Dataset


def load_network(network,params):
    """多卡训练时读入模型"""
    save_path = params['load_state']
    state_dict = torch.load(save_path)
    # create new OrderedDict that does not contain `module.`
    from collections import OrderedDict
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        namekey = k[7:] # remove `module.`
        new_state_dict[namekey] = v
    # load params
    network.load_state_dict(new_state_dict)
    return network


def main():
    config = opt.opts()
    if not os.path.exists('./output'):
        os.mkdir('output')
    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])
    os.makedirs('models/%s' % config['name'], exist_ok=True)

    print('-' * 20)
    for key in config:
        print('%s: %s' % (key, config[key]))
    print('-' * 20)

    with open('models/%s/config.yml' % config['name'], 'w') as f:
        yaml.dump(config, f)

    # create model--------------------------------------------------------------------------------
    print("=> creating model %s" % config['arch'])
    model = None
    if config['arch'] == 'UNet_3Plus':
        if config['deep_supervision'] == True:
            model = UNet_3Plus.UNet_3Plus_DeepSup(in_channels=config['in_channel'],
                                                      n_classes=config['num_classes'],
                                                      feature_scale=4,
                                                      is_deconv=True,
                                                      is_batchnorm=True)
        else:
            model = UNet_3Plus.UNet_3Plus(in_channels = config['in_channel'],
                                          n_classes = config['num_classes'],
                                          feature_scale = 4,
                                          is_deconv = True,
                                          is_batchnorm = True)

    elif config['arch'] == 'UNet_2Plus':
        model = UNet_2Plus.UNet_2Plus(in_channels=config['in_channel'],
                                      n_classes=config['num_classes'],
                                      feature_scale=4,
                                      is_deconv=True,
                                      is_batchnorm=True,
                                      is_ds=True)
    else:
        model = archs.__dict__[config['arch']](config['num_classes'],
                                               config['input_channels'],
                                               config['deep_supervision'])

    # set GPU------------------------------------------------------------------------------------------------
    gpu_num = None
    device = None
    if config['gpu_num'] is not None:
        gpu_num = [int(i) for i in config['gpu_num'].split(',')]
        if len(gpu_num) == 1:
            print('current used gpu is:', str(config['gpu_num']))
            # os.environ["CUDA_VISIBLE_DEVICES"] = str(config['gpu_num'])  # 单卡
            device = torch.device('cuda:'+ str(config['gpu_num']))
            # pdb.set_trace()
        else:
            #device=torch.device("cuda:1" )
            print("用于训练的GPU编号：",gpu_num)
            os.environ["CUDA_VISIBLE_DEVICES"] = config['gpu_num']  #指定卡训练
            gpu_ids=[i for i in range(len(gpu_num))]
            model = nn.DataParallel(model, device_ids=gpu_ids)  # multi-GPU
            #model.to(device)
    # load state --------------------------------------------------------------------------------
    if config['load_state'] is not None:
        print('.....加载权重........')
        if config['cuda'] == True and len(gpu_num)>1:
            model=load_network(model, config)
        else:
            model.load_state_dict(torch.load(config['load_state'])) #,map_location='cpu'
    if config['cuda'] == True:
        model = model.to(device)

    # set loss------------------------------------------------------------------------------------

    if config['loss'] == 'BCEWithLogitsLoss':
        criterion = nn.BCEWithLogitsLoss()
    elif config['loss'] == 'MSSSIMLoss':
        criterion = {}
        # criterion['BceLoss'] = nn.BCELoss(size_average=True)
        a_320_aug = torch.tensor([0.04, 0.044, 0.14, 0.03, 0.12, 0.036, 0.14, 0.1, 0.24, 0.11]).to(device).reshape(1, config['num_classes'])
        criterion['BceLoss'] = FocalLoss.focal_loss(gamma=2, alpha=a_320_aug)
        criterion['iouLoss'] = iouLoss.IOU()
        criterion['MSSSIMLoss'] = msssimLoss.MSSSIM()
    elif config['loss'] == 'FocalLoss':
        criterion = {}
        a_320_aug = torch.tensor([0.04, 0.044, 0.14, 0.03, 0.12, 0.036, 0.14, 0.1, 0.24, 0.11]).to(device).reshape(1,config['num_classes'])
        criterion['BceLoss'] = FocalLoss.focal_loss(gamma=2, alpha=a_320_aug)
        criterion['iouLoss'] = iouLoss.IOU()
    else:
        criterion = losses.__dict__[config['loss']]()

    if config['cuda'] == True:
        if config['loss'] == 'MSSSIMLoss':
            criterion['BceLoss'] = criterion['BceLoss'].to(device)
            criterion['iouLoss'] = criterion['iouLoss'].to(device)
            criterion['MSSSIMLoss'] = criterion['MSSSIMLoss'].to(device)
        elif config['loss'] == 'FocalLoss':
            criterion['BceLoss'] = criterion['BceLoss'].to(device)
            criterion['iouLoss'] = criterion['iouLoss'].to(device)
        else:
            criterion = criterion.to(device)
    cudnn.benchmark = True

    # set optimizer ------------------------------------------------------------------------------------
    params = filter(lambda p: p.requires_grad, model.parameters())
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(
            params, lr=config['lr'], weight_decay=config['weight_decay'])
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'],
                              nesterov=config['nesterov'], weight_decay=config['weight_decay'])
    else:
        raise NotImplementedError

    # set lr scheduler -------------------------------------------------------------------------------------
    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')], gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    else:
        raise NotImplementedError

    # Data loading code--------------------------------------------------------------------------------------------
    img_ids = glob(os.path.join(config['data_path'], config['dataset'], 'images', '*' + config['img_ext']))
    img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]

    train_img_ids, val_img_ids = train_test_split(img_ids, test_size=config['test_size'], random_state=41)

    # set dataloader -----------------------------------------------------------------------------------
    train_dataset = Dataset(
        img_ids=train_img_ids,
        img_dir=os.path.join(config['data_path'], config['dataset'], 'images'),
        mask_dir=os.path.join(config['data_path'], config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'])
        # transform=train_transform)
    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir=os.path.join(config['data_path'], config['dataset'], 'images'),
        mask_dir=os.path.join(config['data_path'], config['dataset'], 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'])
        # transform=val_transform)

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=False)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    log = OrderedDict([
        ('epoch', []),
        ('lr', []),

        # ('train_Acc',[]),
        # ('train_mIoU', []),
        # ('train_FWIoU', []),
        # ('train_loss', []),
        # ('train_bce_loss', []),
        # ('train_msssim_loss', []),
        # ('train_iou_loss', []),

        ('val_Acc', []),
        ('val_mIoU', []),
        ('val_FWIoU', []),
        ('val_loss', []),
        # ('val_bce_loss', []),
        # ('val_msssim_loss', []),
        # ('val_iou_loss', [])
    ])

    # start train and val ------------------------------------------------------------------------------
    best_iou = 0
    trigger = 0
    start_epoch=config['start_epoch']
    for epoch in range(start_epoch+1,config['epochs']+1):
        print('Epoch [%d/%d]' % (epoch, config['epochs']))
        draw_img_ids = np.random.choice(val_img_ids, 1)
        config['draw_val_ids'] = draw_img_ids
        # train for one epoch
        train_log = RunEpoch.train(config, train_loader, model, criterion, optimizer, device)
        # evaluate on validation set
        val_log = RunEpoch.validate(config, val_loader, model, criterion, device)

        if config['scheduler'] == 'CosineAnnealingLR':
            scheduler.step()
        elif config['scheduler'] == 'ReduceLROnPlateau':
            scheduler.step(val_log['loss'])

        log['epoch'].append(epoch)
        log['lr'].append(config['lr'])

        # log['train_Acc'].append(train_log['Acc'])
        # log['train_mIoU'].append(train_log['mIoU'])
        # log['train_FWIoU'].append(train_log['FWIoU'])
        # log['train_loss'].append(train_log['loss'])
        # log['train_bce_loss'].append(train_log['bce_loss'])
        # log['train_msssim_loss'].append(train_log['msssim_loss'])
        # log['train_iou_loss'].append(train_log['iou_loss'])

        log['val_Acc'].append(val_log['Acc'])
        log['val_mIoU'].append(val_log['mIoU'])
        log['val_FWIoU'].append(val_log['FWIoU'])
        log['val_loss'].append(val_log['loss'])
        # log['val_bce_loss'].append(val_log['bce_loss'])
        # log['val_msssim_loss'].append(val_log['msssim_loss'])
        # log['val_iou_loss'].append(val_log['iou_loss'])

        pd.DataFrame(log).to_csv('models/%s/log.csv' %
                                 config['name'], index=False)

        trigger += 1

        if val_log['iou'] > best_iou:
            torch.save(model.state_dict(), 'models/%s/model.pth' %
                       config['name'])
            best_iou = val_log['iou']
            print("=> saved best model")
            trigger = 0

        if epoch%50 == 0:
            torch.save(model.state_dict(), 'models/{}/model_epoch{}.pth' .format(
                       config['name'],epoch))
        # early stopping
        if config['early_stopping'] >= 0 and trigger >= config['early_stopping']:
            print("=> early stopping")
            break
        if config['cuda'] == True:
            torch.cuda.empty_cache()

if __name__ == '__main__':
    main()
