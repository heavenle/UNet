import argparse
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
from glob import glob
import numpy as np
import cv2
import torch
import torchvision
import torch.backends.cudnn as cudnn
import yaml
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose
from sklearn.model_selection import train_test_split
from tqdm import tqdm

import archs
from PIL import Image
import matplotlib.pyplot as plt


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default='datasets_NestedUNet_woDS',
                        help='model name')

    args = parser.parse_args()

    return args

def cut_image(src_img,rate,img_w,img_h,val_transform):
    print('Cutting image starting...')
    X_height, X_width, _ = src_img.shape
    # print(X_height, X_width)

    #重叠量
    val_overlap=int(rate*img_w)

    sub_imgs_list=[]
    sub_imgs_pos_list=[]  #子图起始坐标
    start_h=0
    end_h=img_h

    count=0
    while end_h < X_height:
        if start_h+img_h<=X_height:
            end_h=start_h+img_h
        else:
            end_h=X_height  #列向最后一次
            start_h=X_height-img_h

        start_w = 0
        end_w = img_w

        while end_w < X_width:
            if start_w+img_w <= X_width:
                end_w=start_w+img_w
            else:
                end_w=X_width
                start_w=X_width-img_w

            src_roi=src_img[start_h:end_h,start_w:end_w]
            src_roi = val_transform(image=src_roi)['image']

            src_roi=src_roi.astype('float32') / 255
            src_roi = src_roi.transpose(2, 0, 1)

            sub_imgs_list.append(src_roi)
            sub_imgs_pos_list.append([start_h,end_h,start_w,end_w])

            count+=1
            #更新横向起点
            start_w=start_w+img_w-val_overlap

        #更新列向起点
        start_h=start_h+img_h-val_overlap
    return sub_imgs_list,sub_imgs_pos_list

def main():
    args = parse_args()

    with open('models/%s/config.yml' % args.name, 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    config['cuda']=False
    print('-'*20)
    for key in config.keys():
        print('%s: %s' % (key, str(config[key])))
    print('-'*20)

    cudnn.benchmark = True

    # create model
    print("=> creating model %s" % config['arch'])
    model = archs.__dict__[config['arch']](config['num_classes'],
                                           config['input_channels'],
                                           config['deep_supervision'])

    model = torch.nn.DataParallel(model)  #多卡训练时使用

    if  config['cuda']:
        model = model.cuda()

    model.load_state_dict(torch.load('models/%s/model_1024×1024.pth' %
                                     config['name'],map_location='cpu'))
    model.eval()

    val_transform = Compose([
        # transforms.Resize(config['input_h'], config['input_w']),
        transforms.Normalize()
    ])

    #打开图片并裁剪
    test_img_path = 'F:/data/wuxi-GF2-3/subImgs/rawImgs/notSamples'
    img_name_list=os.listdir(test_img_path)
    for img_name in img_name_list:
        if img_name != 'img1_9.tif':
            continue
        test_img=cv2.imread(os.path.join(test_img_path,img_name))
        print("当前正在处理：",os.path.join(test_img_path,img_name))
        img_w=1024    #根据训练尺寸确定
        img_h=1024

        X_height, X_width, _ = test_img.shape
        result=np.zeros((X_height, X_width))

        sub_imgs_list,sub_imgs_pos_list=cut_image(test_img,0.25,img_w,img_h,val_transform)

        print('predicting sub images...')
        batch_size=2
        iter_num=(len(sub_imgs_pos_list)+1)//batch_size

        #创建文件夹保存子图
        img_save_path=os.path.join('outputs',img_name.split('.')[0]+'_predicted')
        if not os.path.exists(img_save_path):
            os.mkdir(img_save_path)
        sub_img_save_path=os.path.join(img_save_path,'subImamgs')
        if not  os.path.exists(sub_img_save_path):
            os.mkdir(sub_img_save_path)

        with torch.no_grad():
        #每次预测batch_size个子图
            for i in tqdm(range(iter_num)):
                if i==iter_num-1:
                    end=len(sub_imgs_pos_list)
                else:
                    end=(i+1)*batch_size
                imgs=np.array(sub_imgs_list[i*batch_size:end])
                imgs_pos_list=sub_imgs_pos_list[i*batch_size:end]
                imgs = torch.Tensor(imgs)
                input=imgs
                if config['cuda']:
                    input = input.cuda()
                    target = target.cuda()
                output = model(input)
                output = torch.sigmoid(output).cpu().numpy()

                for j in range(len(imgs_pos_list)):
                    start_h,end_h,start_w,end_w=imgs_pos_list[j]
                    sub_img_predicted=(output[j,0]*255).astype('uint8')
                    result[start_h:end_h,start_w:end_w]=sub_img_predicted

                    #保存预测图
                    sub_img_name=img_name.split('.')[0]+'____H='+str(start_h)+'---'+str(end_h)+'____W='+str(start_w)+'---'+str(end_w)+'.tif'
                    # cv2.imwrite(os.path.join(sub_img_save_path,sub_img_name),sub_img_predicted)

                    sub_img_predicted=Image.fromarray(sub_img_predicted)
                    sub_img_predicted.save(os.path.join(sub_img_save_path,sub_img_name))
                # print('已完成{}/{}预测'.format(end,len(sub_imgs_pos_list)))

        pre_path=os.path.join(img_save_path,img_name.split('.')[0]+'_predicted.tif')
        result=Image.fromarray(result)
        Image.MAX_IMAGE_PIXELS = None
        result.save(pre_path)
        # cv2.imwrite(pre_path,(result*255).astype('uint8'))

        blend_images(os.path.join(test_img_path,img_name), pre_path)
    # print('IoU: %.4f' % avg_meter.avg)
    torch.cuda.empty_cache()

def blend_images(path1,path2):
# 将分割图和原图合在一起
    # image1 原图
    # image2 分割图
    Image.MAX_IMAGE_PIXELS = None
    image1 = Image.open(path1)
    image2 = Image.open(path2)

    image1 = image1.convert('RGBA')
    image2 = image2.convert('RGBA')

    # 两幅图像进行合并时，按公式：blended_img = img1 * (1 – alpha) + img2* alpha 进行
    image = Image.blend(image1, image2, 0.3)
    save_path=path2.split('.')[0]+'_blend.tif'
    image.save(save_path)
    # image.show()

if __name__ == '__main__':
    main()
    # test_img_path = 'F:/data/wuxi-GF2-3/subImgs/rawImgs/notSamples'
    # img_name_list=os.listdir(test_img_path)
    # for img_name in img_name_list:
    #     img_name='img1_4.tif'
    #     main(test_img_path,img_name)

    # path1='F:/data/wuxi-GF2-3/subImgs/rawImgs/images/img1_2.tif'
    # path2='E:/pythonProject/pytorch-nested-unet-WUXI/outputs/img1_2_predicted/rawImgs_predicted.tif'
    # blend_images(path1, path2)

