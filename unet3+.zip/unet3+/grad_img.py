import cv2
import numpy as np
import skimage.io as io

def sobel_img(img):
    # 利用sobel算子计算图像的梯度
    # img = io.imread("1.tif")  # 读入一副图像，其中包括alpha的值  imread_unchanged
    # cv2.sobel(src,ddepth,dx,dy,[ksize]) ddepth表示图像的深度，
    #  当处理为8位图像时，当梯度小于0时，会自动变成0，造成边界图像丢失
    # 一般设置为cv2.CV_64F
    sobelx = cv2.Sobel(img, cv2.CV_64F, dx=1, dy=0)  # x方向的
    # 使cv2.convertScaleAbs()函数将结果转化为原来的uint8的形式
    sobelx = cv2.convertScaleAbs(sobelx)

    sobely = cv2.Sobel(img, cv2.CV_64F, dx=0, dy=1)  # y方向的
    sobely = cv2.convertScaleAbs(sobely)

    result = cv2.addWeighted(sobelx, 0.5, sobely, 0.5, 0)  # x方向和y方向的梯度
    result = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)

    return result


if __name__=='__main__':
    img = cv2.imread("3.tif")
    result = sobel_img(img)[:, :, np.newaxis]
    img = np.concatenate((img, result), axis=2)
    cv2.imshow("Original",img)
    cv2.imshow("result",result/255)
    cv2.waitKey()
    cv2.destroyAllWindows()
