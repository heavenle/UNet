# UNet 3+
Code for ICASSP 2020 paper ‘UNet 3+: A full-scale connected unet for medical image segmentation’

## Requirements
* python 3.6.2
* pytorch 1.3.1
