# -*- coding: utf-8 -*-
"""
Created on Mon Aug  9 09:12:46 2021

@author: Administrator
"""
from skimage import io
from PIL import Image
import numpy as np
import os

from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True
Image.MAX_IMAGE_PIXELS = None


def creat_dataset(path1,path2,rate,img_w,img_h):
    print('crop image starting...')
    path_id = path1.split('\\')[-1].split('.')[0]

    print('原图：',path1)
    print('mask:',path2)
    src_img = Image.open(path1)
    src_img = src_img.convert('RGB')
    src_img = np.array(src_img)
    # print(src_img.shape)

    label_img = io.imread(path2)
    # print(label_img.shape)

    X_height, X_width, _ = src_img.shape
    # print(X_height, X_width)

    # row_crop = X_height // img_w
    # col_crop = X_width // img_w
    # print(row_crop,col_crop)

    #保存原图
    val_overlap=int(rate*img_w)

    start_h=0
    end_h=img_h

    count=0
    while end_h < X_height:
        if start_h+img_h<=X_height:
            end_h=start_h+img_h
        else:
            end_h=X_height  #列向最后一次
            start_h=X_height-img_h

        start_w = 0
        end_w = img_w

        while end_w < X_width:
            if start_w+img_w <= X_width:
                end_w=start_w+img_w
            else:
                end_w=X_width
                start_w=X_width-img_w

            src_roi=src_img[start_h:end_h,start_w:end_w]
            label_roi = label_img[start_h:end_h,start_w:end_w]

            name_str=path_id+'--h_' + str(start_h) + '-' + str(end_h) + 'w_' + str(start_w) + '-' + str(end_w) +'.tif'
            io.imsave('F:/data/wuxi-GF2-3/dataset/images/' + name_str, src_roi)
            io.imsave('F:/data/wuxi-GF2-3/dataset/masks/' + name_str, label_roi)
            count+=1
            #更新横向起点
            start_w=start_w+img_w-val_overlap

        #更新列向起点
        start_h=start_h+img_h-val_overlap
    return count

img_w = 512*2
img_h = 512*2

base_path=r'F:\data\wuxi-GF2-3\subImgs'
all_file2_list=os.listdir(os.path.join(base_path,'mask'))

count_src_imgs=0
count_sub_imgs=0

while False:
    for file_name in all_file2_list:
        if file_name.split('.')[-1] == 'tif':
            count_src_imgs+=1
            path1=os.path.join(base_path,'rawImgs',file_name)
            path2=os.path.join(base_path,'mask',file_name)
            count_sub_imgs_temp=creat_dataset(path1,path2,0.25,img_w,img_h)
            count_sub_imgs+=count_sub_imgs_temp

    print('共裁剪{}张图像，得到{}张子图'.format(count_src_imgs,count_sub_imgs))
    break
from skimage import io,data, exposure
base_path='F:/data/wuxi-GF2-3/dataset1'
imgs_name_list=os.listdir(base_path+'/masks')

print('图片数量：',len(imgs_name_list))
for img_name in imgs_name_list:
    src_img_path=os.path.join(base_path,'images',img_name)
    mask_path = os.path.join(base_path, 'masks', img_name)
    if not os.path.exists(src_img_path):
        print(src_img_path)
    img=io.imread(src_img_path)
    result=exposure.is_low_contrast(img)
    if result:
        print("remove image:",img_name)
        mask_path = os.path.join(base_path, 'masks', img_name)
        os.remove(src_img_path)
        os.remove(mask_path)