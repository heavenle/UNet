import yaml
import argparse
import losses
import archs
from utils import AverageMeter, str2bool
import os

ARCH_NAMES = archs.__all__
LOSS_NAMES = losses.__all__
LOSS_NAMES.append('BCEWithLogitsLoss')

def opts():

    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu_num', default=None,
                        help='model name: (default: arch+timestamp)')
    parser.add_argument('--name', default=None,
                        help='model name: (default: arch+timestamp)')
    parser.add_argument('--load_state', default=None,
                        help='state dict: (default: None)')
    parser.add_argument('--start_epoch', default=0 ,type=int, metavar='N',
                        help='number of start epochs to run')
    parser.add_argument('--epochs', default=10, type=int, metavar='N',
                        help='number of total epochs to run')

    parser.add_argument('-b', '--batch_size', default=1, type=int,
                        metavar='N', help='mini-batch size (default: 16)')
    parser.add_argument('-cuda',  default=False, type=bool,
                        help='use cuda or not  (default:False)')
    # model
    parser.add_argument('--arch', '-a', metavar='ARCH', default='NestedUNet',
                        choices=ARCH_NAMES,
                        help='model architecture: ' +
                             ' | '.join(ARCH_NAMES) +
                             ' (default: NestedUNet)')
    parser.add_argument('--deep_supervision', default=False, type=str2bool)
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classes')
    parser.add_argument('--input_w', default=1024, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=1024, type=int,
                        help='image height')

    # loss
    parser.add_argument('--loss', default='BCEDiceLoss',
                        choices=LOSS_NAMES,
                        help='loss: ' +
                             ' | '.join(LOSS_NAMES) +
                             ' (default: BCEDiceLoss)')

    # dataset
    parser.add_argument('--dataset', default='datasets',
                        help='dataset name')
    parser.add_argument('--img_ext', default='.tif',
                        help='image file extension')
    parser.add_argument('--mask_ext', default='.tif',
                        help='mask file extension')

    # optimizer
    parser.add_argument('--optimizer', default='SGD',
                        choices=['Adam', 'SGD'],
                        help='loss: ' +
                             ' | '.join(['Adam', 'SGD']) +
                             ' (default: Adam)')
    parser.add_argument('--lr', '--learning_rate', default=1e-3, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    parser.add_argument('--weight_decay', default=1e-4, type=float,
                        help='weight decay')
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')

    # scheduler
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR'])
    parser.add_argument('--min_lr', default=1e-5, type=float,
                        help='minimum learning rate')
    parser.add_argument('--factor', default=0.1, type=float)
    parser.add_argument('--patience', default=2, type=int)
    parser.add_argument('--milestones', default='1,2', type=str)
    parser.add_argument('--gamma', default= 2 /3, type=float)
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')

    parser.add_argument('--num_workers', default=4, type=int)

    config = parser.parse_args()
    # --------------------------------------------------
    # 判断是否有预设的yaml文件。

    if os.path.exists('config.yml'):
        print('config.yml is existed, we will reloda config')
        with open('config.yml', 'r', encoding='UTF-8') as f:
            config = yaml.load(f.read())

    config['name'] = None
    config['load_state'] = None

    config['colors'] = []
    config['cn_name'] = []
    config['class_value'] = []
    config['name_title_map'] = {}
    dict_labels = eval(config['labels'])
    for i, val in enumerate(dict_labels):
        for key in val.keys():
            if key == "class_color":
                color_ = val[key]
                color_tuple = tuple(int(num) for num in color_.split(','))
                config['colors'].append(color_tuple)
            elif key == "class_title":
                config['cn_name'].append(val[key])
                config['name_title_map'][val['class_name']] = val[key]
            elif key == 'class_value':
                config['class_value'].append(val['class_value'])
            else:
                    continue
    return config

if __name__ == '__main__':
    config = opts()
    print(config)