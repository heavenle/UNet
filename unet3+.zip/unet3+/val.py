import argparse
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
from glob import glob
import numpy as np
import cv2
import torch
import torch.backends.cudnn as cudnn
import yaml
from albumentations.augmentations import transforms
from albumentations.core.composition import Compose
from sklearn.model_selection import train_test_split
from tqdm import tqdm

import archs
from dataset import Dataset
from metrics import iou_score,Evaluator,Metrics
from utils import AverageMeter


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default='datasets_NestedUNet_woDS',
                        help='model name')

    args = parser.parse_args()

    return args


def main():
    args = parse_args()

    with open('models/%s/config.yml' % args.name, 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    config['cuda']=True
    config['batch_size']=1
    print('-'*20)
    for key in config.keys():
        print('%s: %s' % (key, str(config[key])))
    print('-'*20)

    cudnn.benchmark = True

    # create model
    print("=> creating model %s" % config['arch'])
    model = archs.__dict__[config['arch']](config['num_classes'],
                                           config['input_channels'],
                                           config['deep_supervision'])

    model = torch.nn.DataParallel(model)

    if  config['cuda']:
        model = model.cuda()

    #指定测试数据集路径
    test_path='inputs/datasets'
    # Data loading code
    img_ids = glob(os.path.join(test_path, 'images', '*' + config['img_ext']))
    img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]

    _, val_img_ids = train_test_split(img_ids, test_size=0.1, random_state=41)

    print('测试集数量：',len(val_img_ids))

    model.load_state_dict(torch.load('models/%s/model_epoch400.pth' %
                                     config['name'],map_location='cpu'))
    model.eval()

    val_transform = Compose([
        # transforms.Resize(config['input_h'], config['input_w']),
        transforms.Normalize(),
    ])

    val_dataset = Dataset(
        img_ids=img_ids,
        img_dir=os.path.join(test_path, 'images'),
        mask_dir=os.path.join(test_path, 'masks'),
        img_ext=config['img_ext'],
        mask_ext=config['mask_ext'],
        num_classes=config['num_classes'],
        transform=val_transform)

    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    avg_meter = AverageMeter()

    for c in range(config['num_classes']):
        os.makedirs(os.path.join('outputs', config['name'], str(c)), exist_ok=True)

    n_class = 2
    evaluator = Evaluator(n_class)
    train_metrics = Metrics(n_class)

    with torch.no_grad():
        for input, target, meta in tqdm(val_loader, total=len(val_loader)):
            if  config['cuda']:
                input = input.cuda()
                target = target.cuda()

            # compute output
            if config['deep_supervision']:
                output = model(input)[-1]
            else:
                output = model(input)

            iou = iou_score(output, target)
            avg_meter.update(iou, input.size(0))

            pred = torch.sigmoid(output).cpu().numpy()
            target = target.cpu().numpy()

            pred = np.rint(pred).astype(int)
            target = target.astype(int)

            evaluator.add_batch(target, pred)
            train_metrics.add(target, pred)  # 平台性能指标
            # for i in range(len(output)):
            #     for c in range(config['num_classes']):
            #         cv2.imwrite(os.path.join('outputs', config['name'], str(c), meta['img_id'][i] + '.jpg'),
            #                     (output[i, c] * 255).astype('uint8'))

        train_epoch_pr = train_metrics.get_precision()
        train_epoch_re = train_metrics.get_recall()
        train_epoch_fs = train_metrics.get_f_score()
        train_epoch_iou = train_metrics.get_fg_iou()
        train_epoch_pr_mean = sum(train_epoch_pr) / len(train_epoch_pr)
        train_epoch_re_mean = sum(train_epoch_re) / len(train_epoch_re)
        train_epoch_fs_mean = sum(train_epoch_fs) / len(train_epoch_fs)
        train_epoch_iou_mean = sum(train_epoch_iou) / len(train_epoch_iou)

        Acc = evaluator.Pixel_Accuracy()
        Acc_class = evaluator.Pixel_Accuracy_Class()
        mIoU = evaluator.Mean_Intersection_over_Union()
        FWIoU = evaluator.Frequency_Weighted_Intersection_over_Union()
        print('acc={:.4f}    acc_class={:.4f}   miou={:.4f} fwiou={:.4f}'.format(Acc, Acc_class, mIoU, FWIoU))
        print('pre={:.4f}    fs={:.4f} recall={:.4f}    miou={:.4f}'.format(train_epoch_pr_mean, train_epoch_fs_mean,
                                                                            train_epoch_re_mean, train_epoch_iou_mean))
    # print('IoU: %.4f ' % avg_meter.avg)

    torch.cuda.empty_cache()

from PIL import Image
import matplotlib.pyplot as plt
def show_images(path1,path2):
# 将分割图和原图合在一起
    # image1 原图
    # image2 分割图
    image1 = Image.open(path1)
    image2 = Image.open(path2)

    image1 = image1.convert('RGBA')
    image2 = image2.convert('RGBA')

    # 两幅图像进行合并时，按公式：blended_img = img1 * (1 – alpha) + img2* alpha 进行
    image = Image.blend(image1, image2, 0.3)
    save_path=path2.split('.')[0]+'_blend.png'
    image.save(save_path)
    # image.show()

if __name__ == '__main__':
    main()

    # #原图和预测图绘制在同一幅图中
    # base_path=r'E:\pythonProject\pytorch-nested-unet-WUXI\outputs\datasets_NestedUNet_woDS\0'
    # img_name_list=os.listdir(base_path)
    # for img_name in img_name_list:
    #     if 'blend' not in img_name:
    #         path1='F:/data/wuxi-GF2-3/test_dataset\images'+'/'+img_name.split('.')[0]+'.tif'
    #         path2=r'E:\pythonProject\pytorch-nested-unet-WUXI\outputs\datasets_NestedUNet_woDS\0'+'\\'+img_name.split('.')[0]+'.jpg'
    #         show_images(path1,path2)