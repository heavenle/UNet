import os
import time

import opt
import cv2
import numpy as np
import torch
import torch.utils.data
import skimage.io as io
import grad_img

def mask2onehotmask(mask, config):
    one_hot_mask = []
    for class_value in config['class_value']:
        one_hot_mask.append(np.where(mask == int(class_value), 1, 0).astype(np.float32))
    one_hot_mask = np.dstack(one_hot_mask)
    return one_hot_mask



class Dataset(torch.utils.data.Dataset):
    def __init__(self, img_ids, img_dir, mask_dir, img_ext, mask_ext, num_classes,transform=None):
        """
        Args:
            img_ids (list): Image ids.
            img_dir: Image file directory.
            mask_dir: Mask file directory.
            img_ext (str): Image file extension.
            mask_ext (str): Mask file extension.
            num_classes (int): Number of classes.
            transform (Compose, optional): Compose transforms of albumentations. Defaults to None.
        
        Note:
            Make sure to put the files as the following structure:
            <dataset name>
            ├── images
            |   ├── 0a7e06.jpg
            │   ├── 0aab0a.jpg
            │   ├── 0b1761.jpg
            │   ├── ...
            |
            └── masks
                ├── 0
                |   ├── 0a7e06.png
                |   ├── 0aab0a.png
                |   ├── 0b1761.png
                |   ├── ...
                |
                ├── 1
                |   ├── 0a7e06.png
                |   ├── 0aab0a.png
                |   ├── 0b1761.png
                |   ├── ...
                ...
        """
        self.img_ids = img_ids
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.img_ext = img_ext
        self.mask_ext = mask_ext
        self.num_classes = num_classes
        self.transform = transform
        self.config = opt.opts()

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, idx):
        img_id = self.img_ids[idx]

        if self.img_ext == '.npy':
            img = np.load(os.path.join(self.img_dir, img_id + self.img_ext))
            img = img[:, :, 0:3]

        else:
            img = cv2.imread(os.path.join(self.img_dir, img_id + self.img_ext))
            img = cv2.resize(img, (self.config['input_w'], self.config['input_h']))

        mask = []
        if self.img_ext == '.npy':
            mask = np.load(os.path.join(self.mask_dir, img_id + self.mask_ext))
        elif self.img_ext == '.tif':
            mask = cv2.imread(os.path.join(self.mask_dir, img_id + self.mask_ext), 0)
            mask = cv2.resize(mask, (self.config['input_w'], self.config['input_h']))
        else:
            for i in range(self.num_classes):
                img_path=os.path.join(self.mask_dir,
                            img_id + self.mask_ext)
                #print("img-path=",img_path)
                mask.append(io.imread(img_path)[..., None])
            mask = np.dstack(mask)

        # if self.transform is not None:
        #     augmented = self.transform(image=img, mask=mask)
        #     img = augmented['image']
        #     mask = augmented['mask']
        if self.config['use_gradent'] == True:
            sobel_img = grad_img.sobel_img(img)[:, :, np.newaxis]
            img = np.concatenate((img, sobel_img), axis=2)
        img = img.astype('float32') / 255.
        img = img.transpose(2, 0, 1)

        if self.config['arch'] == 'UNet_3Plus' or self.config['arch'] == 'UNet_2Plus':
            mask = mask2onehotmask(mask, self.config)
            mask = mask.transpose(2, 0, 1)
        
        else:
            mask = mask.astype('float32') / 255.
            mask = mask.transpose(2, 0, 1)
        
        return img, mask, {'img_id': img_id}
